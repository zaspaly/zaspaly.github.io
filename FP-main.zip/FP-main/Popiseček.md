Praxe z firmy RETIA - Skupinový projekt: "Plně automatizovaná fotopast"
